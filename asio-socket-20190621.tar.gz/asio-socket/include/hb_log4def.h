//
// Created by huanghao on 19-5-15.
//

#ifndef HBAUDITFLOW_HB_LOG4DEF_H
#define HBAUDITFLOW_HB_LOG4DEF_H

#include "hbla_log4.h"

#define PRO_NAME "asio"

#endif //HBAUDITFLOW_HB_LOG4DEF_H
